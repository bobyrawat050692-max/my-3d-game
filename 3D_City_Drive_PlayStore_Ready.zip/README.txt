3D City Drive

Run:
1. Open terminal in this folder
2. yarn
3. yarn dev
4. Open the localhost URL shown by Vite

Controls: W/A/S/D or Arrow keys.
