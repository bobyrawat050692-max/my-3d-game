import { Canvas, useFrame } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import "./App.css";

function Car() {
  const car = useRef();
  const [keys, setKeys] = useState({});

  useEffect(() => {
    const down = e => setKeys(k => ({ ...k, [e.key.toLowerCase()]: true }));
    const up = e => setKeys(k => ({ ...k, [e.key.toLowerCase()]: false }));
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, []);

  useFrame((_, delta) => {
    if (!car.current) return;
    const speed = 7 * delta;

    if (keys.w || keys.arrowup) car.current.position.z -= speed;
    if (keys.s || keys.arrowdown) car.current.position.z += speed;
    if (keys.a || keys.arrowleft) car.current.position.x -= speed;
    if (keys.d || keys.arrowright) car.current.position.x += speed;

    car.current.position.x = THREE.MathUtils.clamp(car.current.position.x, -4.2, 4.2);

    const turning = (keys.a || keys.arrowleft) ? 0.25 :
                    (keys.d || keys.arrowright) ? -0.25 : 0;
    car.current.rotation.y = THREE.MathUtils.lerp(car.current.rotation.y, turning, 0.15);
  });

  return (
    <group ref={car} position={[0, 0.7, 5]}>
      <mesh><boxGeometry args={[1.8, 0.6, 3.2]} /><meshStandardMaterial color="#d71920" /></mesh>
      <mesh position={[0, 0.5, -0.2]}><boxGeometry args={[1.35, 0.65, 1.5]} /><meshStandardMaterial color="#222831" /></mesh>
      <mesh position={[-0.55, 0.02, -1.65]}><boxGeometry args={[0.35, 0.2, 0.08]} /><meshStandardMaterial color="white" emissive="white" emissiveIntensity={2} /></mesh>
      <mesh position={[0.55, 0.02, -1.65]}><boxGeometry args={[0.35, 0.2, 0.08]} /><meshStandardMaterial color="white" emissive="white" emissiveIntensity={2} /></mesh>
      {[[-1,-0.7,1.05],[1,-0.7,1.05],[-1,-0.7,-1.05],[1,-0.7,-1.05]].map((p,i) =>
        <mesh key={i} position={p} rotation={[0,0,Math.PI/2]}>
          <cylinderGeometry args={[0.38,0.38,0.25,24]} />
          <meshStandardMaterial color="#111" />
        </mesh>
      )}
    </group>
  );
}

function Road() {
  return <group>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,-0.05,-30]}>
      <planeGeometry args={[80,150]} /><meshStandardMaterial color="#4b8b3b" />
    </mesh>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,0,-30]}>
      <planeGeometry args={[10,150]} /><meshStandardMaterial color="#333" />
    </mesh>
    {Array.from({length:30}).map((_,i)=>
      <mesh key={i} rotation={[-Math.PI/2,0,0]} position={[0,0.02,-i*5]}>
        <planeGeometry args={[0.25,2.5]} /><meshStandardMaterial color="white" />
      </mesh>
    )}
    <mesh position={[-5,0.08,-30]}><boxGeometry args={[0.2,0.15,150]} /><meshStandardMaterial color="white" /></mesh>
    <mesh position={[5,0.08,-30]}><boxGeometry args={[0.2,0.15,150]} /><meshStandardMaterial color="white" /></mesh>
  </group>;
}

function Buildings() {
  return <group>
    {Array.from({length:20}).map((_,i) => {
      const side = i%2===0 ? -1 : 1;
      return <mesh key={i} position={[side*(8+(i%3)),1.5+(i%2),-i*7]}>
        <boxGeometry args={[4,3+(i%3),4]} />
        <meshStandardMaterial color={i%2 ? "#d7b899" : "#8fa7c2"} />
      </mesh>;
    })}
  </group>;
}

function Trees() {
  return <group>
    {Array.from({length:25}).map((_,i) => {
      const side = i%2===0 ? -1 : 1;
      return <group key={i} position={[side*(6+(i%3)),0,-i*6-3]}>
        <mesh position={[0,1,0]}><cylinderGeometry args={[0.18,0.25,2,12]} /><meshStandardMaterial color="#6b3f20" /></mesh>
        <mesh position={[0,2.2,0]}><sphereGeometry args={[1,16,16]} /><meshStandardMaterial color="#218c3a" /></mesh>
      </group>;
    })}
  </group>;
}

function CameraFollow() {
  useFrame(({camera}) => {
    camera.position.lerp(new THREE.Vector3(0,5.5,13),0.05);
    camera.lookAt(0,0,-10);
  });
  return null;
}

function Game() {
  return <Canvas camera={{position:[0,5.5,13],fov:60}}>
    <color attach="background" args={["#87ceeb"]} />
    <ambientLight intensity={1.5} />
    <directionalLight position={[10,15,10]} intensity={2} />
    <Road /><Buildings /><Trees /><Car />
    <CameraFollow />
    <OrbitControls enablePan={false} enableZoom={false} maxPolarAngle={Math.PI/2.1} />
  </Canvas>;
}

export default function App() {
  return <div className="game">
    <Game />
    <div className="ui">
      <h1>🚗 3D CITY DRIVE</h1>
      <div className="controls"><b>Controls</b><br/>W / ↑ = Accelerate<br/>S / ↓ = Reverse<br/>A / ← = Left<br/>D / → = Right</div>
    </div>
  </div>;
}
